go to the directory: pirate_kingdom in terminal and type npm start to start the project
The game should be on: http://localhost:3000/
